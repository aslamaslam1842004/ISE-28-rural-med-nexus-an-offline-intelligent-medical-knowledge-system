import warnings
import os
import sys
from io import StringIO

# Suppress gpt4all CUDA DLL loading warnings (using CPU mode anyway)
warnings.filterwarnings('ignore', message='.*llamamodel.*dll.*')
os.environ['GLOG_minloglevel'] = '2'

# Redirect stderr to suppress C++ DLL loading messages
_stderr = sys.stderr
sys.stderr = StringIO()

import streamlit as st
from src.rag.pipeline import answer_query

# Restore stderr after imports
sys.stderr = _stderr

st.set_page_config(page_title="Offline Medical Assistant", page_icon="🩺", layout="centered")

# ─── Medical Theme CSS ────────────────────────────────────────────────────────
st.markdown("""
<style>
    .stApp {
        background: linear-gradient(135deg, #0a0f1e 0%, #0d1b2a 40%, #0a1628 70%, #061020 100%);
        min-height: 100vh;
    }
    .main .block-container {
        background: rgba(10, 20, 40, 0.85);
        border: 1px solid rgba(0, 160, 255, 0.15);
        border-radius: 16px;
        padding: 2.5rem 3rem;
        box-shadow: 0 0 60px rgba(0, 100, 255, 0.08), 0 0 120px rgba(0, 200, 150, 0.04), inset 0 1px 0 rgba(255,255,255,0.05);
        backdrop-filter: blur(10px);
        margin-top: 1rem;
    }
    h1 { color: #ffffff !important; font-size: 2.1rem !important; font-weight: 700 !important; letter-spacing: -0.5px; text-shadow: 0 0 30px rgba(0, 160, 255, 0.4); }
    .stCaption, [data-testid="stCaptionContainer"] { color: rgba(100, 180, 255, 0.7) !important; font-size: 0.85rem !important; letter-spacing: 0.5px; }
    label, .stSelectbox label, [data-testid="stWidgetLabel"] { color: rgba(140, 200, 255, 0.9) !important; font-weight: 600 !important; font-size: 0.9rem !important; text-transform: uppercase; letter-spacing: 0.8px; }
    .stSelectbox > div > div { background: rgba(0, 30, 60, 0.8) !important; border: 1px solid rgba(0, 160, 255, 0.3) !important; border-radius: 10px !important; color: #e0f0ff !important; }
    .stSelectbox > div > div:hover { border-color: rgba(0, 200, 150, 0.5) !important; box-shadow: 0 0 20px rgba(0, 200, 150, 0.1) !important; }
    [data-baseweb="select"] span { color: #c0e0ff !important; }
    .stButton > button { background: linear-gradient(135deg, #0055cc 0%, #0077ee 50%, #00aacc 100%) !important; color: #ffffff !important; border: none !important; border-radius: 10px !important; padding: 0.65rem 2.5rem !important; font-weight: 700 !important; font-size: 0.95rem !important; letter-spacing: 0.5px; text-transform: uppercase; box-shadow: 0 4px 20px rgba(0, 100, 255, 0.35); transition: all 0.2s ease; width: 100%; }
    .stButton > button:hover { background: linear-gradient(135deg, #0066dd 0%, #0099ff 50%, #00ccdd 100%) !important; box-shadow: 0 6px 30px rgba(0, 150, 255, 0.5) !important; transform: translateY(-1px); }
    h2, h3 { color: #7dd8ff !important; font-weight: 600 !important; }
    .answer-box { background: rgba(0, 40, 80, 0.6); border: 1px solid rgba(0, 200, 150, 0.25); border-left: 3px solid #00cc88; border-radius: 10px; padding: 1.2rem 1.5rem; color: #d0eeff; font-size: 1rem; line-height: 1.7; box-shadow: 0 2px 20px rgba(0, 200, 150, 0.08); margin-bottom: 1rem; }
    .stExpander { background: rgba(0, 20, 50, 0.5) !important; border: 1px solid rgba(0, 100, 200, 0.2) !important; border-radius: 10px !important; }
    .source-card { background: rgba(0, 30, 70, 0.7); border: 1px solid rgba(0, 120, 200, 0.2); border-radius: 8px; padding: 0.5rem 1rem; margin: 0.3rem 0; color: #90c8ff; font-size: 0.85rem; }
    hr { border-color: rgba(0, 100, 200, 0.15) !important; margin: 1.5rem 0 !important; }
    .disclaimer { background: rgba(255, 140, 0, 0.06); border: 1px solid rgba(255, 140, 0, 0.2); border-radius: 10px; padding: 0.7rem 1.2rem; color: #ffcc66; font-size: 0.82rem; margin-top: 2rem; text-align: center; }
    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: rgba(0,20,50,0.5); }
    ::-webkit-scrollbar-thumb { background: rgba(0,120,255,0.3); border-radius: 3px; }
</style>
""", unsafe_allow_html=True)

# ─── Predefined Questions ──────────────────────────────────────────────────────
QUESTION_GROUPS = {
    "── Fever ──": [
        "What is fever?",
        "How is fever treated according to the documents?",
        "What medicines are mentioned for fever management?",
        "What care is recommended during fever?",
        "What food or habits should be avoided during fever?",
    ],
    "── Diarrhea & Vomiting ──": [
        "How is diarrhea managed according to the documents?",
        "What is recommended for dehydration?",
        "What role does ORS play in illness management?",
        "What care is suggested for vomiting?",
        "What fluids are recommended during diarrhea or vomiting?",
    ],
    "── Stomach-Related Care ──": [
        "What treatment is suggested for stomach pain?",
        "What dietary advice is mentioned for stomach-related discomfort?",
        "What medicines are mentioned for stomach issues?",
    ],
    "── Headache & Body Pain ──": [
        "How is headache managed according to the documents?",
        "What treatment is suggested for body pain?",
    ],
    "── Medications & Medical Mentions ──": [
        "Is Paracetamol mentioned in the medical documents?",
        "Are antacid tablets recommended in any condition?",
        "What medicines are repeatedly mentioned across the documents?",
    ],
    "── Public Health / Guidelines ──": [
        "What preventive measures are discussed in the documents?",
        "What general health care advice is provided in the documents?",
    ],
}

ALL_OPTIONS = ["— Select a question —"]
for group, questions in QUESTION_GROUPS.items():
    ALL_OPTIONS.append(group)
    ALL_OPTIONS.extend(questions)

# ─── Header ───────────────────────────────────────────────────────────────────
st.markdown("# 🩺 Offline Medical RAG Assistant")
st.caption("Runs fully offline • Privacy-preserving • Powered by local AI")
st.markdown("---")

# ─── Dropdown ─────────────────────────────────────────────────────────────────
selected = st.selectbox(
    "Select a medical question",
    options=ALL_OPTIONS,
    index=0,
    help="Choose a question from the list to retrieve an answer from the medical documents.",
)

is_valid_question = (
    selected != "— Select a question —"
    and not selected.startswith("──")
)

ask_clicked = st.button("🔍 Ask", disabled=not is_valid_question)

# ─── Answer Logic ─────────────────────────────────────────────────────────────
if ask_clicked and is_valid_question:
    with st.spinner("🔬 Searching medical knowledge base..."):
        response = answer_query(selected)

    st.markdown("---")
    st.subheader("💡 Answer")
    st.markdown(
        f'<div class="answer-box">{response["answer"]}</div>',
        unsafe_allow_html=True,
    )

    raw_sources = response.get("sources", [])
    seen = set()
    unique_sources = []
    for src in raw_sources:
        if src not in seen:
            seen.add(src)
            unique_sources.append(src)

    total_count = len(raw_sources)
    unique_count = len(unique_sources)

    with st.expander(
        f"📚 Sources — {unique_count} unique document{'s' if unique_count != 1 else ''} ({total_count} chunk{'s' if total_count != 1 else ''} retrieved)",
        expanded=True,
    ):
        if unique_sources:
            for src in unique_sources:
                parts = src.split(" | ")
                display = parts[-1] if len(parts) > 1 else src
                st.markdown(
                    f'<div class="source-card">📄 {display}</div>',
                    unsafe_allow_html=True,
                )
        else:
            st.info("No sources found.")

elif ask_clicked and not is_valid_question:
    st.warning("Please select a valid question from the dropdown.")

# ─── Disclaimer ───────────────────────────────────────────────────────────────
st.markdown(
    '<div class="disclaimer">⚠️ This system is for educational purposes only and is not a substitute for professional medical advice.</div>',
    unsafe_allow_html=True,
)
