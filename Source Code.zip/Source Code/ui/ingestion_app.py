import sys
import os
import warnings
from pathlib import Path
from io import StringIO

# Suppress gpt4all C++ DLL loading warnings early
warnings.filterwarnings('ignore', message='.*llamamodel.*dll.*')
os.environ['GLOG_minloglevel'] = '2'

# Redirect stderr to suppress C++ DLL loading messages
_stderr = sys.stderr
sys.stderr = StringIO()

# -----------------------------
# Fix import path for Streamlit
# -----------------------------
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(PROJECT_ROOT))

import streamlit as st

# Restore stderr after imports
sys.stderr = _stderr
from src.ingestion.ingestion import run_ingestion_pipeline

st.set_page_config(page_title="Medical RAG – Ingestion", page_icon="📥", layout="centered")

# ─── Medical Theme CSS (matches query_app) ────────────────────────────────────
st.markdown("""
<style>
    .stApp {
        background: linear-gradient(135deg, #0a0f1e 0%, #0d1b2a 40%, #0a1628 70%, #061020 100%);
        min-height: 100vh;
    }
    .main .block-container {
        background: rgba(10, 20, 40, 0.85);
        border: 1px solid rgba(0, 160, 255, 0.15);
        border-radius: 16px;
        padding: 2.5rem 3rem;
        box-shadow: 0 0 60px rgba(0, 100, 255, 0.08), 0 0 120px rgba(0, 200, 150, 0.04), inset 0 1px 0 rgba(255,255,255,0.05);
        backdrop-filter: blur(10px);
        margin-top: 1rem;
    }
    h1 { color: #ffffff !important; font-size: 2.1rem !important; font-weight: 700 !important; letter-spacing: -0.5px; text-shadow: 0 0 30px rgba(0, 160, 255, 0.4); }
    .stCaption, [data-testid="stCaptionContainer"] { color: rgba(100, 180, 255, 0.7) !important; font-size: 0.85rem !important; letter-spacing: 0.5px; }
    label, [data-testid="stWidgetLabel"] { color: rgba(140, 200, 255, 0.9) !important; font-weight: 600 !important; font-size: 0.9rem !important; text-transform: uppercase; letter-spacing: 0.8px; }
    /* File uploader */
    [data-testid="stFileUploader"] { background: rgba(0, 30, 60, 0.6) !important; border: 1.5px dashed rgba(0, 160, 255, 0.35) !important; border-radius: 12px !important; padding: 1rem !important; }
    [data-testid="stFileUploader"]:hover { border-color: rgba(0, 200, 150, 0.5) !important; box-shadow: 0 0 20px rgba(0, 200, 150, 0.08) !important; }
    /* Buttons */
    .stButton > button { background: linear-gradient(135deg, #0055cc 0%, #0077ee 50%, #00aacc 100%) !important; color: #ffffff !important; border: none !important; border-radius: 10px !important; padding: 0.65rem 2.5rem !important; font-weight: 700 !important; font-size: 0.95rem !important; letter-spacing: 0.5px; text-transform: uppercase; box-shadow: 0 4px 20px rgba(0, 100, 255, 0.35); transition: all 0.2s ease; width: 100%; }
    .stButton > button:hover { background: linear-gradient(135deg, #0066dd 0%, #0099ff 50%, #00ccdd 100%) !important; box-shadow: 0 6px 30px rgba(0, 150, 255, 0.5) !important; transform: translateY(-1px); }
    h2, h3 { color: #7dd8ff !important; font-weight: 600 !important; }
    hr { border-color: rgba(0, 100, 200, 0.15) !important; margin: 1.5rem 0 !important; }
    /* Success / Info */
    [data-testid="stAlert"] { border-radius: 10px !important; }
    .disclaimer { background: rgba(255, 140, 0, 0.06); border: 1px solid rgba(255, 140, 0, 0.2); border-radius: 10px; padding: 0.7rem 1.2rem; color: #ffcc66; font-size: 0.82rem; margin-top: 2rem; text-align: center; }
    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: rgba(0,20,50,0.5); }
    ::-webkit-scrollbar-thumb { background: rgba(0,120,255,0.3); border-radius: 3px; }

    /* Info card */
    .info-card { background: rgba(0, 40, 80, 0.5); border: 1px solid rgba(0, 160, 255, 0.2); border-radius: 10px; padding: 1rem 1.5rem; color: #a0d0ff; font-size: 0.88rem; line-height: 1.6; margin-bottom: 1.2rem; }
    .info-card strong { color: #60d0ff; }
</style>
""", unsafe_allow_html=True)

# ─── Header ───────────────────────────────────────────────────────────────────
st.markdown("# 📥 Medical Data Ingestion")
st.caption("Upload medical documents and build the offline RAG knowledge base")
st.markdown("---")

# ─── Info card ────────────────────────────────────────────────────────────────
st.markdown("""
<div class="info-card">
    <strong>Supported formats:</strong> PDF, DOCX, TXT (documents) &nbsp;•&nbsp;
    PNG, JPG, JPEG (images) &nbsp;•&nbsp; MP3, WAV (audio)<br>
    After uploading, click <strong>Run Ingestion Pipeline</strong> to process and index the files.
</div>
""", unsafe_allow_html=True)

# ─── File Uploader (unchanged logic) ─────────────────────────────────────────
uploaded_files = st.file_uploader(
    "Upload medical files",
    type=[
        "pdf", "docx", "txt",
        "png", "jpg", "jpeg",
        "mp3", "wav"
    ],
    accept_multiple_files=True
)

if uploaded_files:
    for file in uploaded_files:
        suffix = file.name.split(".")[-1].lower()

        if suffix in ["pdf", "docx", "txt"]:
            save_dir = Path("input/documents")
        elif suffix in ["png", "jpg", "jpeg"]:
            save_dir = Path("input/images")
        else:
            save_dir = Path("input/audio")

        save_dir.mkdir(parents=True, exist_ok=True)

        with open(save_dir / file.name, "wb") as f:
            f.write(file.read())

    st.success(f"✅ {len(uploaded_files)} file{'s' if len(uploaded_files) != 1 else ''} uploaded successfully.")

st.markdown("---")

if st.button("⚙️ Run Ingestion Pipeline"):
    with st.spinner("🔄 Running ingestion pipeline — this may take a moment..."):
        run_ingestion_pipeline()
    st.success("✅ Ingestion completed successfully. The knowledge base has been updated.")

# ─── Disclaimer ───────────────────────────────────────────────────────────────
st.markdown(
    '<div class="disclaimer">⚠️ This system is for educational purposes only and is not a substitute for professional medical advice.</div>',
    unsafe_allow_html=True,
)
