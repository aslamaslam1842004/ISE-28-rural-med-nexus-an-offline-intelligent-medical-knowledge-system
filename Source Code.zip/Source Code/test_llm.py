from src.llm.local_llm import generate

print("Starting...")
print(generate("What is fever?"))
print("Done.")
