import json
from pathlib import Path
from typing import List, Dict

import nltk


nltk.download("punkt", quiet=True)
nltk.download("punkt_tab", quiet=True)

from loguru import logger


from nltk.tokenize import sent_tokenize


# -----------------------------
# CONFIG
# -----------------------------
INPUT_DIR = Path("processed/text")
OUTPUT_DIR = Path("processed/chunks")

CHUNK_SIZE = 500       # approx words
CHUNK_OVERLAP = 80


# -----------------------------
# HELPERS
# -----------------------------
def chunk_text(text: str) -> List[str]:
    sentences = sent_tokenize(text)
    chunks = []
    current_chunk = []
    current_length = 0

    for sentence in sentences:
        words = sentence.split()
        if current_length + len(words) <= CHUNK_SIZE:
            current_chunk.append(sentence)
            current_length += len(words)
        else:
            chunks.append(" ".join(current_chunk))

            overlap_words = " ".join(current_chunk).split()[-CHUNK_OVERLAP:]
            current_chunk = [" ".join(overlap_words), sentence]
            current_length = len(overlap_words) + len(words)

    if current_chunk:
        chunks.append(" ".join(current_chunk))

    return chunks


# -----------------------------
# CORE
# -----------------------------
def chunk_documents() -> List[Dict]:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    chunked_docs = []

    files = list(INPUT_DIR.glob("*.json"))
    logger.info(f"Chunking {len(files)} document(s)")

    for file in files:
        with open(file, "r", encoding="utf-8") as f:
            doc = json.load(f)

        chunks = chunk_text(doc["content"])

        for idx, chunk in enumerate(chunks):
            chunk_doc = {
                "chunk_id": f"{file.stem}_{idx}",
                "content": chunk,
                "source": doc["source"],
                "filename": doc["filename"],
                "modality": doc["modality"],
                "domain": doc["domain"]
            }

            chunked_docs.append(chunk_doc)

        # Save chunked version per document
        output_file = OUTPUT_DIR / f"{file.stem}_chunks.json"
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(chunked_docs, f, indent=2, ensure_ascii=False)

    logger.info(f"Generated {len(chunked_docs)} chunks")
    return chunked_docs


if __name__ == "__main__":
    chunk_documents()
