from src.query.query_engine import run_query


def answer_query(query: str, top_k: int = 5):
    answer, chunks = run_query(query, top_k)

    sources = []
    for chunk in chunks:
        src = f"{chunk.get('source')} | {chunk.get('filename')}"
        sources.append(src)

    return {
        "answer": answer,
        "sources": sources
    }
