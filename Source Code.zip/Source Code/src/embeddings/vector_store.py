import json
from pathlib import Path
from typing import List, Dict

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from loguru import logger


# -----------------------------
# CONFIG
# -----------------------------
CHUNKS_DIR = Path("processed/chunks")
INDEX_DIR = Path("embeddings/faiss_index")
INDEX_DIR.mkdir(parents=True, exist_ok=True)

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"


# -----------------------------
# CORE
# -----------------------------
def build_faiss_index():
    logger.info("Loading embedding model...")
    model = SentenceTransformer(MODEL_NAME)

    all_chunks: List[Dict] = []
    for file in CHUNKS_DIR.glob("*_chunks.json"):
        with open(file, "r", encoding="utf-8") as f:
            all_chunks.extend(json.load(f))

    logger.info(f"Embedding {len(all_chunks)} chunks")

    texts = [chunk["content"] for chunk in all_chunks]
    embeddings = model.encode(texts, show_progress_bar=True)

    embeddings = np.array(embeddings).astype("float32")

    dim = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)

    # Save index
    faiss.write_index(index, str(INDEX_DIR / "medical_rag.index"))

    # Save metadata
    with open(INDEX_DIR / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(all_chunks, f, indent=2, ensure_ascii=False)

    logger.info("FAISS index built successfully")


if __name__ == "__main__":
    build_faiss_index()
