import os
import json
from pathlib import Path
from typing import List, Dict

from pypdf import PdfReader
from docx import Document
from loguru import logger
from tqdm import tqdm


# -----------------------------
# CONFIG
# -----------------------------
INPUT_DIR = Path("input/documents")
OUTPUT_DIR = Path("processed/text")

SUPPORTED_EXTENSIONS = [".pdf", ".docx", ".txt"]


# -----------------------------
# HELPERS
# -----------------------------
def extract_text_from_pdf(file_path: Path) -> str:
    reader = PdfReader(file_path)
    text = []
    for page in reader.pages:
        if page.extract_text():
            text.append(page.extract_text())
    return "\n".join(text)


def extract_text_from_docx(file_path: Path) -> str:
    doc = Document(file_path)
    return "\n".join([para.text for para in doc.paragraphs if para.text.strip()])


def extract_text_from_txt(file_path: Path) -> str:
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def extract_text(file_path: Path) -> str:
    if file_path.suffix == ".pdf":
        return extract_text_from_pdf(file_path)
    elif file_path.suffix == ".docx":
        return extract_text_from_docx(file_path)
    elif file_path.suffix == ".txt":
        return extract_text_from_txt(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_path.suffix}")


# -----------------------------
# CORE LOADER
# -----------------------------
def load_documents() -> List[Dict]:
    documents = []

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    files = [
        file
        for file in INPUT_DIR.rglob("*")
        if file.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    logger.info(f"Found {len(files)} document(s)")

    for file_path in tqdm(files, desc="Loading documents"):
        try:
            text = extract_text(file_path)

            if not text.strip():
                logger.warning(f"Empty content: {file_path}")
                continue

            doc = {
                "content": text,
                "source": str(file_path),
                "filename": file_path.name,
                "modality": "document",
                "file_type": file_path.suffix.replace(".", ""),
                "domain": "medical"
            }

            documents.append(doc)

            # Save individual JSON
            output_file = OUTPUT_DIR / f"{file_path.stem}.json"
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(doc, f, indent=2, ensure_ascii=False)

        except Exception as e:
            logger.error(f"Failed to process {file_path}: {e}")

    return documents


# -----------------------------
# ENTRY POINT
# -----------------------------
if __name__ == "__main__":
    logger.add("logs/pipeline.log", rotation="1 MB")

    docs = load_documents()
    logger.info(f"Successfully processed {len(docs)} document(s)")
