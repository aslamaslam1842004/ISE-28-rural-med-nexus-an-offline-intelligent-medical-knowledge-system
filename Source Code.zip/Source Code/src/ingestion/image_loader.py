import pytesseract

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

import json
from pathlib import Path
from typing import List, Dict

from loguru import logger
from PIL import Image
import pytesseract


# -----------------------------
# CONFIG
# -----------------------------
INPUT_DIR = Path("input/images")
OUTPUT_DIR = Path("processed/text")

SUPPORTED_EXTENSIONS = [".png", ".jpg", ".jpeg"]


# -----------------------------
# CORE
# -----------------------------
def load_images() -> List[Dict]:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if not INPUT_DIR.exists():
        logger.warning("Image input folder not found. Skipping image ingestion.")
        return []

    files = [
        f for f in INPUT_DIR.rglob("*")
        if f.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    if not files:
        logger.warning("No image files found. Skipping image ingestion.")
        return []

    logger.info(f"Found {len(files)} image(s)")

    documents = []

    for file_path in files:
        try:
            image = Image.open(file_path)
            text = pytesseract.image_to_string(image)

            if not text.strip():
                logger.warning(f"No text detected in image: {file_path}")
                continue

            doc = {
                "content": text,
                "source": str(file_path),
                "filename": file_path.name,
                "modality": "image",
                "file_type": file_path.suffix.replace(".", ""),
                "domain": "medical"
            }

            documents.append(doc)

            output_file = OUTPUT_DIR / f"{file_path.stem}_image.json"
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(doc, f, indent=2, ensure_ascii=False)

        except Exception as e:
            logger.error(f"Failed to process image {file_path}: {e}")

    return documents
