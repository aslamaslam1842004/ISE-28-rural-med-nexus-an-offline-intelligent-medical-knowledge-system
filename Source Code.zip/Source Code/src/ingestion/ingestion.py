from loguru import logger
from pathlib import Path

# -----------------------------
# Import pipeline steps
# -----------------------------
from src.ingestion.document_loader import load_documents
from src.ingestion.image_loader import load_images
from src.ingestion.audio_loader import load_audio
from src.preprocessing.chunker import chunk_documents
from src.embeddings.vector_store import build_faiss_index


# -----------------------------
# CONFIG
# -----------------------------
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)


# -----------------------------
# INGESTION PIPELINE
# -----------------------------
def run_ingestion_pipeline():
    logger.info("===== STARTING INGESTION PIPELINE =====")

    all_docs = []

    # 1️⃣ Documents
    logger.info("Step 1: Loading documents")
    docs = load_documents()
    logger.info(f"Loaded {len(docs)} document(s)")
    all_docs.extend(docs)

    # 2️⃣ Images
    logger.info("Step 2: Loading images")
    imgs = load_images()
    logger.info(f"Loaded {len(imgs)} image(s)")
    all_docs.extend(imgs)

    # 3️⃣ Audio
    logger.info("Step 3: Loading audio")
    audios = load_audio()
    logger.info(f"Loaded {len(audios)} audio file(s)")
    all_docs.extend(audios)

    if not all_docs:
        logger.warning("No data ingested from any modality. Skipping chunking and indexing.")
        logger.info("===== INGESTION PIPELINE COMPLETED (NO DATA) =====")
        return

    # 4️⃣ Chunking
    logger.info("Step 4: Chunking text data")
    chunks = chunk_documents()
    logger.info(f"Generated {len(chunks)} chunks")

    if not chunks:
        logger.warning("No chunks generated. Skipping vector indexing.")
        logger.info("===== INGESTION PIPELINE COMPLETED (NO CHUNKS) =====")
        return

    # 5️⃣ FAISS Index
    logger.info("Step 5: Building FAISS index")
    build_faiss_index()

    logger.info("===== INGESTION PIPELINE COMPLETED SUCCESSFULLY =====")


# -----------------------------
# ENTRY POINT
# -----------------------------
if __name__ == "__main__":
    logger.add("logs/ingestion.log", rotation="1 MB")
    run_ingestion_pipeline()
