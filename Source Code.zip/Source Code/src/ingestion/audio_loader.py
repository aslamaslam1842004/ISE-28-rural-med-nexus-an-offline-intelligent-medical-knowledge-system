import os

os.environ["PATH"] += os.pathsep + r"C:\Users\aslam\Downloads\ffmpeg-8.0.1-essentials_build\ffmpeg-8.0.1-essentials_build\bin"

import json
from pathlib import Path
from typing import List, Dict

from loguru import logger
import whisper


# -----------------------------
# CONFIG
# -----------------------------
INPUT_DIR = Path("input/audio")
OUTPUT_DIR = Path("processed/text")

SUPPORTED_EXTENSIONS = [".mp3", ".wav", ".m4a", ".mpeg"]
WHISPER_MODEL = "base"   # offline, lightweight


# -----------------------------
# CORE
# -----------------------------
def load_audio() -> List[Dict]:
    """Load audio files from `INPUT_DIR`, transcribe with Whisper, and
    write JSON documents to `OUTPUT_DIR`.
    """

    # Ensure output directory exists
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if not INPUT_DIR.exists():
        logger.warning("Audio input folder not found. Skipping audio ingestion.")
        return []

    files = [
        f for f in INPUT_DIR.rglob("*")
        if f.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    if not files:
        logger.warning("No audio files found. Skipping audio ingestion.")
        return []

    logger.info(f"Found {len(files)} audio file(s)")

    model = whisper.load_model(WHISPER_MODEL)
    documents = []

    for file_path in files:
        try:
            result = model.transcribe(str(file_path))
            text = result.get("text", "").strip()

            if not text:
                logger.warning(f"No speech detected in audio: {file_path}")
                continue

            doc = {
                "content": text,
                "source": str(file_path),
                "filename": file_path.name,
                "modality": "audio",
                "file_type": file_path.suffix.replace(".", ""),
                "domain": "medical",
            }

            documents.append(doc)

            output_file = OUTPUT_DIR / f"{file_path.stem}_audio.json"
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(doc, f, indent=2, ensure_ascii=False)

        except Exception as e:
            logger.error(f"Failed to process audio {file_path}: {e}")

    return documents
