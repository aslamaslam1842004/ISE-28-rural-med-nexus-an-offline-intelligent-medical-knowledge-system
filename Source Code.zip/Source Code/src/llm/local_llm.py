import os
from pathlib import Path
import streamlit as st
from gpt4all import GPT4All

# Force CPU only
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

_MODEL_PATH = Path(r"C:\Users\aslam\.cache\gpt4all")
_MODEL_NAME = "mistral-7b-instruct.gguf"


@st.cache_resource(show_spinner=False)
def load_llm():
    return GPT4All(
        model_name=_MODEL_NAME,
        model_path=str(_MODEL_PATH),
        allow_download=False,
        device="cpu"
    )


def generate(prompt: str) -> str:
    llm = load_llm()

    return llm.generate(
        prompt=prompt,
        max_tokens=64,   # 🔴 LOWER = safer
        temp=0.1,
        top_p=0.9
    ).strip()
