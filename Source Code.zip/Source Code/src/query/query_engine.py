from src.query.retriever import retrieve
from src.query.answer_generator import generate_answer


def run_query(query: str, top_k: int = 4):
    retrieved_chunks = retrieve(query, top_k)
    answer = generate_answer(query, retrieved_chunks)
    return answer, retrieved_chunks
