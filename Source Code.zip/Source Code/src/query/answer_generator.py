from src.llm.local_llm import generate
from src.query.prompt_builder import build_prompt

# Safety limits for Mistral-7B
MAX_CHARS_PER_CHUNK = 400
MAX_TOTAL_CONTEXT_CHARS = 1200


def generate_answer(query: str, chunks: list[dict]) -> str:
    if not chunks:
        return "No relevant medical information was found in the documents."

    # Extract and trim chunk content
    contexts = []
    total_chars = 0

    for c in chunks:
        content = c.get("content")
        if not content:
            continue

        trimmed = content[:MAX_CHARS_PER_CHUNK]
        contexts.append(trimmed)
        total_chars += len(trimmed)

        if total_chars >= MAX_TOTAL_CONTEXT_CHARS:
            break

    prompt = build_prompt(query, contexts)

    return generate(prompt)
