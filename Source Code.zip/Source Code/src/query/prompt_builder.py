def build_prompt(query: str, contexts: list[str]) -> str:
    if not contexts:
        return "Information not found in the provided medical documents."

    is_definition = query.lower().startswith("what is")

    context_block = "\n\n".join(contexts)

    if is_definition:
        return f"""
You are a medical assistant.
Provide a concise definition based on the context.
If the context does not explicitly define the term, provide a general medical definition.

Context:
{context_block}

Question:
{query}

Answer:
""".strip()[:3500]

    # strict mode for symptoms/treatment
    return f"""
You are a medical information extraction system.

Use ONLY the words present in the context.
Do NOT infer or guess.
If information is not explicitly stated, reply:
"Information not found in the provided medical documents."

Context:
{context_block}

Question:
{query}

Answer:
""".strip()[:3500]
