import faiss
import json
from pathlib import Path
from src.embeddings.embedder import embed_text

INDEX_DIR = Path("embeddings/faiss_index")
INDEX_PATH = INDEX_DIR / "medical_rag.index"
METADATA_PATH = INDEX_DIR / "metadata.json"


def load_faiss_index():
    index = faiss.read_index(str(INDEX_PATH))

    with open(METADATA_PATH, "r", encoding="utf-8") as f:
        metadata = json.load(f)

    return index, metadata


def _keyword_overlap(query: str, text: str) -> bool:
    query_terms = {w.lower() for w in query.split() if len(w) > 3}
    text_lower = text.lower()

    return any(term in text_lower for term in query_terms)


def retrieve(query: str, top_k: int = 5):
    index, metadata = load_faiss_index()

    query_embedding = embed_text(query)
    distances, indices = index.search(query_embedding, top_k * 3)

    query_lower = query.lower()
    is_definition = query_lower.startswith("what is")

    results = []

    for idx in indices[0]:
        if idx >= len(metadata):
            continue

        chunk = metadata[idx]
        content = chunk.get("content", "")

        # 🔥 STRICT FILTER for non-definition questions
        if not is_definition:
            if not _keyword_overlap(query, content):
                continue

        results.append(chunk)

        if len(results) >= top_k:
            break

    return results
